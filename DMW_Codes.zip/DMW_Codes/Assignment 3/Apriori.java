import java.util.*;

public class Apriori
{
	
	static ArrayList<String> list = new ArrayList<String>();	
	static HashMap<String,Integer> g = new HashMap<String,Integer>();
	static HashMap<String,Integer> g1 = new HashMap<String,Integer>();
	static HashMap<String,Integer> prev = new HashMap<String,Integer>();
	static HashMap<String,Integer> first = new HashMap<String,Integer>();
	static String inp[];
	static int count;
	public static void main(String args[])
	{
		Scanner Sc = new Scanner(System.in);
		int n,t,s,c;
		
		System.out.print("\nNumber of transactions : ");
		t = Sc.nextInt();
		
		System.out.print("\nNumber of Items : ");
		n = Sc.nextInt();
		
		System.out.print("\nMinimum Support : ");
		s = Sc.nextInt();
		
		System.out.print("\nMinimum Confidence : ");
		c = Sc.nextInt();
		
		Sc.nextLine();
		System.out.println("\nEnter Items with space\n");
		inp = new String[t];
		for(int i=0;i<t;i++)
		{
			System.out.print("\nTransaction"+(i+1)+" : ");
			inp[i] = Sc.nextLine();
		}
		group(inp);
		count++;
		g1 = (HashMap<String,Integer>)g.clone();
		while(true)
		{
			eleminate(s);
			if(count == 1)
				first = (HashMap<String,Integer>)g1.clone();
			System.out.println("\nIteration "+count+"\n");
			for(Map.Entry o:g1.entrySet())
				System.out.println((String)o.getKey()+" ===> "+o.getValue());
			System.out.println();
			if(g1.isEmpty())
			{
				System.out.println("No items at this iteration\n");
				break;
			}
			prev = (HashMap<String,Integer>)g.clone();
			g = (HashMap<String,Integer>)g1.clone();
			g1.clear();
			group(); 
			
		}
		
		System.out.println("Final List\n");
		for(Map.Entry o:g.entrySet())
			System.out.println((String)o.getKey()+" ===> "+o.getValue());
		System.out.println("\nHence Final Association Rules are \n");
		for(Map.Entry o:g.entrySet())
			confidence((String)o.getKey(),(int)o.getValue(),c);
	}
	
	public static void confidence(String str,int sup,int c)
	{
		String fin[] = str.split(" ");
		int i = (fin.length-1);
		if(c<1)
			c = c*100;
		while(i>=0)
		{
			String fin1="";
			for(int j=0;j<fin.length;j++)
			{
				if(j == i)
					continue;
				fin1+=fin[j];
				if(i == fin.length-1)
				{
					if(j < fin.length-2)
						fin1+=" ";
				}
				else if(j < fin.length-1)
					fin1+=" ";
			}
			int sup1 = prev.get(fin1);
			int sup2 = first.get(fin[i]);
			if(100*sup/sup1 >= c)
				System.out.println(fin1+" => "+fin[i]);
			if(100*sup/sup2 >= c)
				System.out.println(fin[i]+" => "+fin1);
			i--;
		}
		
	}
	
	public static void group()
	{
	
		String temp[] = new String[g.size()];
		int i=0;
		for(Map.Entry o:g.entrySet())
		{
			temp[i] = (String)o.getKey();
			i++;
		}
		
		if(count == 1)
		{			
			for(i=0;i<temp.length;i++)
			{
				for(int j=i+1;j<temp.length;j++)
				{
					g1.put(temp[i]+" "+temp[j],0);
				}
			}
			
		}
		else
		{
			for(i=0;i<temp.length;i++)
			{
				for(int k=i+1;k<temp.length;k++)
				{
					String temp1[] = temp[k].split(" ");
					int count1 = 0;
					for(int j=0;j<temp1.length;j++)
					{
						if(temp[i].contains(temp1[j]))
							count1++;
					}
					if(count1 == (temp1.length-1))
					{
						boolean flag = true;
						String r = temp[i];
						for(int j=0;j<temp1.length;j++)
						{
							if(!r.contains(temp1[j]))
								r+=" "+temp1[j];
						}
						temp1 = r.split(" ");
						for(Map.Entry o:g1.entrySet())
						{
							count1=0;
							for(int j=0;j<temp1.length;j++)
							{
								if(((String)(o.getKey())).contains(temp1[j]))
									count1++;
							}
							if(count1 == temp1.length)
								flag = false;
						}
						if(flag)
							g1.put(r,0);
					}
				}
			}
		}
		
		count++;
	}
	
	public static void group(String[] inp)
	{
		for(int i=0;i<inp.length;i++)
		{
			String inp1[] = inp[i].split(" ");
			for(int j=0;j<inp1.length;j++)
				g.put(inp1[j],0);
		}
	}
	
	public static void eleminate(int s)
	{
		String ele="";
		for(Map.Entry o:g1.entrySet())
		{
			int z = (int)o.getValue();
			String key = (String)o.getKey();
			for(int i=0;i<inp.length;i++)
			{
				String keys[] = key.split(" ");
				if(keys.length > 1)
				{
					int y=0;
					for(int j=0;j<keys.length;j++)
					{
						if(inp[i].contains(keys[j]))
							y++;
					}
					if(y == keys.length)
						z++;
				}
				else if(inp[i].contains(key))
				{
					z++;					
				}
			}
			if(z >= s)
				g1.put((String)o.getKey(),z);
			else
				ele+=","+(String)o.getKey();
		}
		
		String ele1 [] = ele.split(",");
		
		for(int i=0;i<ele1.length;i++)
			g1.remove(ele1[i]);
		
	}
	
}

/*

Number of transactions : 5

Number of Items : 10

Minimum Support : 3

Minimum Confidence : 80

Enter Items with space


Transaction1 : bread butter milk cake egg yoghurt

Transaction1 : doughnut butter milk cake egg yoghurt

Transaction1 : bread apple cake egg

Transaction1 : bread screw biscuit cake yoghurt

Transaction1 : biscuit butter cake egg

Iteration 1

bread ===> 3
butter ===> 3
egg ===> 4
cake ===> 5
yoghurt ===> 3


Iteration 2

yoghurt cake ===> 3
butter egg ===> 3
egg cake ===> 4
bread cake ===> 3
butter cake ===> 3


Iteration 3

butter egg cake ===> 3


Iteration 4

No items at this iteration

Final List

butter egg cake ===> 3

Hence Final Association Rules are 

butter egg => cake
butter cake => egg
butter => egg cake



*/


