import java.util.*;
import java.io.*;
import java.math.*;

public class Stopwords
{
	static BufferedReader br;
	static BufferedWriter bw;
	static HashMap<String,Integer> file1 = new HashMap<String,Integer>();
	static HashMap<String,Integer> file2 = new HashMap<String,Integer>();
	public static void main(String args[])throws Exception
	{
		int x,count=0;
		String z="";
		String stwd = "";
		
		br = new BufferedReader(new InputStreamReader(new FileInputStream("stopwords.txt")));
		
		while((z = br.readLine()) != null)
		{
			stwd+=z+" ";
		}
		z="";
		
		br = new BufferedReader(new InputStreamReader(new FileInputStream("input.txt")));
		bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt")));
		
		while((z = br.readLine()) != null)
		{
			if(count!=0)
				bw.write("\n");
			count = 0;
			String spl[] = z.split(" ");
			for(String str:spl)
			{
				if(!stwd.contains(str))
				{
					if(str.endsWith("ing"))
						str = str.replace("ing","");
					bw.write(str+" ");
					count++;
				}
			}
			
		}
		br.close();
		bw.close();
		classify();
	}
	
	public static void classify()throws Exception
	{
		br = new BufferedReader(new InputStreamReader(new FileInputStream("input.txt")));
		
		String inp="",inp1="",temp="";
		while((temp = br.readLine()) != null)
		{
			inp+=temp+" ";
		}
		temp="";
		br = new BufferedReader(new InputStreamReader(new FileInputStream("output.txt")));
		while((temp = br.readLine()) != null)
		{
			inp1+=temp+" ";
		}
		String spl[] = inp.split(" ");
		String spl1[] = inp1.split(" ");
		
		for(String x:spl)
		{
			if(x.equals("") || x.equals(" "))
				continue;
			if(file1.containsKey(x))
				file1.replace(x,file1.get(x),file1.get(x)+1);
			else
				file1.put(x,1);
			if(!file2.containsKey(x))
				file2.put(x,0);
		}
		for(String x:spl1)
		{
			if(x.equals("") || x.equals(" "))
				continue;
			if(file2.containsKey(x))
				file2.replace(x,file2.get(x),file2.get(x)+1);
			else
				file2.put(x,1);
			if(!file1.containsKey(x))
				file1.put(x,0);
		}
		System.out.println("\n\nDocument1 ====>\n"+file1);
		System.out.println("\n\nDocument2 ====>\n"+file2);
		int[] xy = new int[file1.size()];
		int i=0;
		float mod_x=0,mod_y=0,XY=0;
		for(Map.Entry o:file1.entrySet())
		{
			xy[i] =(int) o.getValue();
			mod_x+=xy[i]*xy[i];
			i++;
		}
		mod_x = (float)Math.sqrt(mod_x);
		i=0;
		for(Map.Entry o:file2.entrySet())
		{
			XY += xy[i]*(int)o.getValue();
			mod_y+=((int)o.getValue())*((int)o.getValue());
			i++;
		}
		mod_y = (float)Math.sqrt(mod_y);
		float cosine = XY/(mod_x*mod_y);
		System.out.println("\nCosine Similarity : "+cosine+"\n\n");
		
	}
	
}
